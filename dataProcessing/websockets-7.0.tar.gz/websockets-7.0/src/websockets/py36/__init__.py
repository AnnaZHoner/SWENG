# This package contains code using async iteration added in Python 3.6.
# It cannot be imported on Python < 3.6 because it triggers syntax errors.
